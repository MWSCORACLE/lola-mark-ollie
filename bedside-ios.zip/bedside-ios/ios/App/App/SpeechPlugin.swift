import Foundation
import Capacitor
import Speech
import AVFoundation

/// Native speech recognition for the speaking exercises.
/// JS calls: available(), checkPermissions(), requestPermissions(), start({language,maxResults}), stop()
/// start() resolves with { matches: [String] } when speech ends (silence) or stop() is called.
@objc(SpeechPlugin)
public class SpeechPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "SpeechPlugin"
    public let jsName = "SpeechRecognition"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "available", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "checkPermissions", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "requestPermissions", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "start", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stop", returnType: CAPPluginReturnPromise),
    ]

    private let audioEngine = AVAudioEngine()
    private var recognizer: SFSpeechRecognizer?
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var pendingCall: CAPPluginCall?
    private var lastMatches: [String] = []
    private var silenceTimer: Timer?

    @objc func available(_ call: CAPPluginCall) {
        let r = SFSpeechRecognizer(locale: Locale(identifier: "es-US")) ?? SFSpeechRecognizer()
        call.resolve(["available": r?.isAvailable ?? false])
    }

    private func permissionState() -> String {
        switch SFSpeechRecognizer.authorizationStatus() {
        case .authorized:
            switch AVAudioSession.sharedInstance().recordPermission {
            case .granted: return "granted"
            case .denied: return "denied"
            default: return "prompt"
            }
        case .denied, .restricted: return "denied"
        default: return "prompt"
        }
    }

    @objc func checkPermissions(_ call: CAPPluginCall) {
        call.resolve(["speechRecognition": permissionState()])
    }

    @objc func requestPermissions(_ call: CAPPluginCall) {
        SFSpeechRecognizer.requestAuthorization { status in
            guard status == .authorized else {
                call.resolve(["speechRecognition": "denied"]); return
            }
            AVAudioSession.sharedInstance().requestRecordPermission { granted in
                call.resolve(["speechRecognition": granted ? "granted" : "denied"])
            }
        }
    }

    @objc func start(_ call: CAPPluginCall) {
        let lang = call.getString("language") ?? "es-US"
        let maxResults = call.getInt("maxResults") ?? 4
        guard permissionState() == "granted" else {
            call.reject("permission denied"); return
        }
        if task != nil { finish(with: lastMatches) }

        recognizer = SFSpeechRecognizer(locale: Locale(identifier: lang))
        guard let recognizer = recognizer, recognizer.isAvailable else {
            call.reject("speech recognition unavailable"); return
        }
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(.record, mode: .measurement, options: .duckOthers)
            try session.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            call.reject("audio session error"); return
        }

        let req = SFSpeechAudioBufferRecognitionRequest()
        req.shouldReportPartialResults = true
        if #available(iOS 13, *) { req.requiresOnDeviceRecognition = false }
        request = req
        pendingCall = call
        lastMatches = []

        let input = audioEngine.inputNode
        let format = input.outputFormat(forBus: 0)
        input.removeTap(onBus: 0)
        input.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            self?.request?.append(buffer)
        }
        audioEngine.prepare()
        do { try audioEngine.start() } catch {
            cleanupAudio(); call.reject("could not start microphone"); return
        }

        task = recognizer.recognitionTask(with: req) { [weak self] result, error in
            guard let self = self else { return }
            if let result = result {
                let alts = result.transcriptions.prefix(maxResults).map { $0.formattedString }
                self.lastMatches = alts.isEmpty ? [result.bestTranscription.formattedString] : Array(alts)
                self.resetSilenceTimer()
                if result.isFinal { self.finish(with: self.lastMatches) }
            }
            if error != nil {
                // Cancelled by stop() or ended by iOS: hand back whatever was heard.
                self.finish(with: self.lastMatches)
            }
        }
        // Hard cap so a lesson never hangs on an open microphone.
        DispatchQueue.main.asyncAfter(deadline: .now() + 12) { [weak self] in
            guard let self = self, self.task != nil else { return }
            self.finish(with: self.lastMatches)
        }
    }

    @objc func stop(_ call: CAPPluginCall) {
        finish(with: lastMatches)
        call.resolve()
    }

    private func resetSilenceTimer() {
        DispatchQueue.main.async {
            self.silenceTimer?.invalidate()
            self.silenceTimer = Timer.scheduledTimer(withTimeInterval: 1.6, repeats: false) { [weak self] _ in
                guard let self = self else { return }
                self.finish(with: self.lastMatches)
            }
        }
    }

    private func finish(with matches: [String]) {
        DispatchQueue.main.async {
            self.silenceTimer?.invalidate(); self.silenceTimer = nil
            self.request?.endAudio()
            self.task?.cancel()
            self.task = nil
            self.request = nil
            self.cleanupAudio()
            if let call = self.pendingCall {
                self.pendingCall = nil
                call.resolve(["matches": matches])
            }
        }
    }

    private func cleanupAudio() {
        if audioEngine.isRunning { audioEngine.stop() }
        audioEngine.inputNode.removeTap(onBus: 0)
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }
}
